# Clim Dimensionnement — projet Android

Application Android native en Kotlin, en français, avec calculs hors ligne et export PDF via le sélecteur de fichiers Android.

## Construire l'APK avec Android Studio
1. Sur un ordinateur, installe Android Studio depuis le site officiel Android Developers.
2. Décompresse `ClimDimensionnement_Projet.zip`.
3. Dans Android Studio, choisis **Open** et sélectionne le dossier `ClimDimensionnement`.
4. Laisse Gradle synchroniser le projet. Le premier build nécessite généralement Internet pour télécharger les outils Android ; l'application fonctionne ensuite hors ligne.
5. Choisis **Build > Build APK(s)**.
6. Clique sur **Locate** quand le build est terminé. Le fichier de test sera normalement `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfère ce fichier sur le Redmi 9, ouvre-le depuis le gestionnaire de fichiers et autorise l'installation de cette source si Android le demande.

## Configuration
- Nom : Clim Dimensionnement
- Identifiant : `com.chiviko.climdimensionnement`
- Android minimum : Android 6.0 (API 23)
- Dépendances externes à l'exécution : aucune
- Internet nécessaire dans l'application : non

## Limites du calcul
Cette version fournit une **estimation pédagogique de première approche**, pas un logiciel réglementaire de calcul thermique. Elle prend en compte les transmissions déclarées des murs, de la toiture et des vitrages, le solaire transmis par les vitrages, les personnes, l'éclairage, les appareils, une approximation sensible de ventilation et une marge de sécurité. La charge latente de l'air neuf, l'humidité, les apports solaires par murs/toiture, les ponts thermiques et les profils horaires ne sont pas entièrement modélisés. Adapter les coefficients aux matériaux et conditions du site et faire vérifier le dimensionnement avant installation.

Les valeurs préremplies sont des exemples modifiables, pas des données universelles pour le Cameroun. Saisis la surface réelle des murs opaques, hors fenêtres.
