package com.chiviko.climdimensionnement

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val fields = linkedMapOf<String, EditText>()
    private var latestReport = ""
    private var resultView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "CLIM DIMENSIONNEMENT"
            textSize = 23f
            setTextColor(Color.rgb(21, 69, 126))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(text("Outil hors ligne • Bilan thermique estimatif", 14f, Color.DKGRAY))
        root.addView(space(14))

        section(root, "1. Identification du chantier")
        addField(root, "Client / chantier", "Chantier sans nom", false)
        addField(root, "Ville / localité", "Douala", false)
        addField(root, "Température intérieure souhaitée (°C)", "25")
        addField(root, "Température extérieure de calcul (°C)", "33")

        section(root, "2. Dimensions et enveloppe")
        addField(root, "Longueur du local (m)", "5")
        addField(root, "Largeur du local (m)", "4")
        addField(root, "Hauteur sous plafond (m)", "2.8")
        addField(root, "Surface totale des murs opaques (m²)", "35")
        addField(root, "Coefficient U des murs (W/m²·K)", "1.8")
        addField(root, "Surface de toiture / plafond exposé (m²)", "20")
        addField(root, "Coefficient U toiture (W/m²·K)", "2.5")
        addField(root, "Surface vitrée totale (m²)", "3")
        addField(root, "Coefficient U des vitrages (W/m²·K)", "5.7")
        addField(root, "Apport solaire par les vitrages (W/m²)", "180")
        addField(root, "Facteur d'exposition solaire (0,5 à 1,5)", "1.0")

        section(root, "3. Charges internes et ventilation")
        addField(root, "Nombre d'occupants", "2")
        addField(root, "Apport sensible par personne (W)", "75")
        addField(root, "Apport latent par personne (W)", "55")
        addField(root, "Éclairage total (W)", "100")
        addField(root, "Appareils électriques dissipant dans le local (W)", "300")
        addField(root, "Débit d'air neuf / infiltration (m³/h)", "30")
        addField(root, "Facteur de sécurité (%)", "10")

        root.addView(Button(this).apply {
            text = "CALCULER LE BILAN THERMIQUE"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(21, 101, 192)))
            setOnClickListener { calculate() }
        }, matchWrap())
        root.addView(space(8))
        root.addView(Button(this).apply {
            text = "EXPORTER LA FICHE PDF"
            setOnClickListener {
                if (latestReport.isBlank()) calculate()
                if (latestReport.isNotBlank()) createPdf()
            }
        }, matchWrap())
        root.addView(space(12))
        resultView = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(20, 55, 40))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(225, 242, 232))
            visibility = View.GONE
        }
        root.addView(resultView, matchWrap())
        root.addView(space(12))
        root.addView(text("Important : estimation indicative. Pour une installation définitive, vérifier les conditions climatiques de calcul, les caractéristiques réelles des parois, l'humidité, les charges latentes et les prescriptions du fabricant.", 12f, Color.DKGRAY))
    }

    private fun calculate() {
        try {
            fun n(label: String): Double = fields[label]?.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()
                ?: throw IllegalArgumentException("Valeur invalide : $label")
            fun s(label: String): String = fields[label]?.text?.toString()?.trim().orEmpty()

            val length = n("Longueur du local (m)")
            val width = n("Largeur du local (m)")
            val height = n("Hauteur sous plafond (m)")
            require(length > 0 && width > 0 && height > 0) { "Les dimensions doivent être supérieures à zéro." }
            val area = length * width
            val volume = area * height
            val dt = max(0.0, n("Température extérieure de calcul (°C)") - n("Température intérieure souhaitée (°C)"))
            val walls = n("Surface totale des murs opaques (m²)") * n("Coefficient U des murs (W/m²·K)") * dt
            val roof = n("Surface de toiture / plafond exposé (m²)") * n("Coefficient U toiture (W/m²·K)") * dt
            val glassArea = n("Surface vitrée totale (m²)")
            val glass = glassArea * n("Coefficient U des vitrages (W/m²·K)") * dt
            val solar = glassArea * n("Apport solaire par les vitrages (W/m²)") * n("Facteur d'exposition solaire (0,5 à 1,5)")
            val people = n("Nombre d'occupants")
            val sensiblePeople = people * n("Apport sensible par personne (W)")
            val latentPeople = people * n("Apport latent par personne (W)")
            val lights = n("Éclairage total (W)")
            val appliances = n("Appareils électriques dissipant dans le local (W)")
            val airflow = n("Débit d'air neuf / infiltration (m³/h)")
            val ventSensible = airflow * 0.34 * dt
            val sensible = walls + roof + glass + solar + sensiblePeople + lights + appliances + ventSensible
            val latent = latentPeople
            val subtotal = sensible + latent
            val safety = n("Facteur de sécurité (%)").coerceIn(0.0, 30.0)
            val total = subtotal * (1.0 + safety / 100.0)
            val btu = total * 3.412142
            val kw = total / 1000.0
            val capacities = listOf(9000, 12000, 18000, 24000, 30000, 36000, 48000, 60000)
            val recommended = capacities.firstOrNull { it >= btu } ?: capacities.last()

            val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            latestReport = listOf(
                "CLIM DIMENSIONNEMENT - RAPPORT DE CALCUL",
                "Date : $date",
                "Client / chantier : ${s("Client / chantier")}",
                "Ville / localité : ${s("Ville / localité")}",
                "",
                "DIMENSIONS",
                "Longueur : ${fmt(length)} m",
                "Largeur : ${fmt(width)} m",
                "Hauteur : ${fmt(height)} m",
                "Surface au sol : ${fmt(area)} m²",
                "Volume : ${fmt(volume)} m³",
                "Écart de température utilisé : ${fmt(dt)} K",
                "",
                "DÉTAIL DES APPORTS (W)",
                "Transmission murs : ${fmt(walls)}",
                "Transmission toiture / plafond : ${fmt(roof)}",
                "Transmission vitrages : ${fmt(glass)}",
                "Apports solaires vitrages : ${fmt(solar)}",
                "Occupants sensibles : ${fmt(sensiblePeople)}",
                "Occupants latents : ${fmt(latentPeople)}",
                "Éclairage : ${fmt(lights)}",
                "Appareils électriques : ${fmt(appliances)}",
                "Ventilation / infiltration sensible : ${fmt(ventSensible)}",
                "Total sensible estimé : ${fmt(sensible)} W",
                "Total latent estimé : ${fmt(latent)} W",
                "Sous-total : ${fmt(subtotal)} W",
                "Marge de sécurité appliquée : ${fmt(safety)} %",
                "CHARGE TOTALE ESTIMÉE : ${fmt(total)} W",
                "Puissance frigorifique : ${fmt(kw)} kW",
                "Équivalent : ${fmt(btu)} BTU/h",
                "Capacité commerciale indicative : $recommended BTU/h",
                "",
                "HYPOTHÈSES ET LIMITES",
                "Calcul simplifié à partir des données saisies.",
                "La ventilation ne comprend que la charge sensible.",
                "La charge latente de l'air neuf, les ponts thermiques, l'inertie, les charges solaires par murs/toiture et les profils d'utilisation ne sont pas modélisés complètement.",
                "Adapter les coefficients aux matériaux, à l'orientation, à l'ombrage et aux conditions locales.",
                "La puissance choisie doit être vérifiée selon les données du fabricant."
            ).joinToString("\n")

            resultView?.text = "RÉSULTAT ESTIMATIF\nSurface : ${fmt(area)} m²   •   Volume : ${fmt(volume)} m³\nCharge totale : ${fmt(total)} W (${fmt(kw)} kW)\nÉquivalent : ${fmt(btu)} BTU/h\nCapacité commerciale indicative : $recommended BTU/h\n\nDétail : murs ${fmt(walls)} W • toiture ${fmt(roof)} W • vitrages ${fmt(glass + solar)} W • charges internes et air ${fmt(sensiblePeople + latentPeople + lights + appliances + ventSensible)} W"
            resultView?.visibility = View.VISIBLE
            Toast.makeText(this, "Calcul terminé. Tu peux exporter la fiche PDF.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Vérifie les valeurs saisies.", Toast.LENGTH_LONG).show()
        }
    }

    private fun createPdf() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "Clim_Dimensionnement.pdf")
        }
        startActivityForResult(intent, CREATE_PDF)
    }

    @Deprecated("Deprecated in Android API but works across supported versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_PDF && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                writePdf(uri, latestReport)
                Toast.makeText(this, "PDF enregistré.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Erreur PDF : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writePdf(uri: Uri, content: String) {
        val doc = PdfDocument()
        val body = Paint().apply { color = Color.BLACK; textSize = 10f; isAntiAlias = true }
        val title = Paint().apply { color = Color.rgb(21, 69, 126); textSize = 16f; typeface = android.graphics.Typeface.DEFAULT_BOLD; isAntiAlias = true }
        val lines = content.lines().flatMap { if (it.length <= 92) listOf(it) else it.chunked(92) }
        var pageNo = 1
        var i = 0
        while (i < lines.size) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            val canvas: Canvas = page.canvas
            canvas.drawText("CLIM DIMENSIONNEMENT", 40f, 38f, title)
            var y = 65f
            while (i < lines.size && y < 800f) {
                canvas.drawText(lines[i], 40f, y, body)
                y += 15f
                i++
            }
            canvas.drawText("Page $pageNo", 520f, 825f, body)
            doc.finishPage(page)
            pageNo++
        }
        contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: throw IllegalStateException("Impossible d'ouvrir le fichier.")
        doc.close()
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(space(12))
        root.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.rgb(21, 69, 126))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        })
    }
    private fun addField(root: LinearLayout, label: String, default: String, numeric: Boolean = true) {
        root.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0, dp(5), 0, dp(3))
        })
        val input = EditText(this).apply {
            setText(default); textSize = 15f; singleLine = true
            setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(Color.WHITE)
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        fields[label] = input
        root.addView(input, matchWrap())
    }
    private fun text(value: String, size: Float, color: Int) = TextView(this).apply { text = value; textSize = size; setTextColor(color) }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(5) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun fmt(value: Double) = String.format(Locale.FRANCE, "%.1f", value)
    companion object { private const val CREATE_PDF = 42 }
}
